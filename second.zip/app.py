from flask import Flask, render_template, request, session, url_for, redirect
import logging
from datetime import timedelta
import time
import Helper

# logging.basicConfig(filename='C:/Users/황현아/Desktop/File4Log/app_system_log.txt', level= logging.DEBUG)
# WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
# Connect to DataBase

#static 경로 차단***********************
host = '127.0.0.1'
user_db = Helper.connect_to_db(host)
self = None

# app setting
app = Helper.setting_app(__name__,10)

def make_response(sorf,msg):
    res = {}
    res['sorf'] = sorf
    res['message'] = msg
    return res

@app.route('/')
def mainPage():
    post_contents = Helper.get_main_posts(user_db,'t_board')
    if post_contents: return render_template('index.html', **post_contents)
    else: return render_template('index.html')

@app.route('/signin',methods=['POST','GET'])
def signinPage():
    if request.method == 'GET':
        return render_template('signin.html')
    elif request.method == 'POST':
        response = {}
        une = request.form['userne']
        upwd = request.form['userpw']
        checking_account = Helper.SignIn.check_account(self, user_db, une, upwd, app)
        if checking_account == True:
            sess = Helper.SignIn.create_session(self,user_db,une)
            session['uname'] = sess
            response['sorf'] = True
            response['message'] = '로그인에 성공했습니다.'
            return response
        else:
            response['sorf'] = False
            response['message'] = checking_account
            return response

@app.route('/signup',methods=['POST','GET'])
def signupPage():
    if request.method == 'GET':
        return render_template('signup.html')
    elif request.method == 'POST':
        uemail = request.form['usermail']
        uname = request.form['username']
        upwd = request.form['userpw']
        check_confirm = Helper.SignUp.check_confirmed(self,user_db,uemail)
        if check_confirm:
            create = Helper.SignUp.create_account(self, user_db, uemail, uname, upwd, app)
            if create == True:
                delete_data = Helper.SignUp.remove_confirm_data(self,user_db,uemail)
                if delete_data:
                    return make_response(True, '회원가입에 성공하였습니다.')
                else: return make_response(False, 'DATABASE ERROR.')
            else: return make_response(False, create)
        else:
            token_sendnadd = Helper.SignUp.sendnadd_token(self,app,user_db,uemail)
            if token_sendnadd != True: return make_response(False,'이메일로 인증 링크 전송에 실패하였습니다. 잠시 후 다시 시도해주세요.')
            else: return make_response(False,'이메일로 인증 링크가 전송 되었습니다. 확인해주세요.')

@app.route('/logout', methods=['GET','POST'])
def logoutPage():
    if request.method == 'GET': return redirect('/')
    elif request.method == 'POST':
        res = {}
        if session['uname']:
            try:
                session.pop('uname', None)
                res['sorf'] = True
            except:
                res['sorf'] = False
            return res
        else:
            res['sorf'] = False
            return res

@app.route('/writelect',methods=['POST'])
def writelecAPI():               #session uname 외 관리자 인증용 세션도 만들어야함. 해쉬도 괜찮을듯
    res = {}
    try:
        title = request.form['title']
        context = request.form['context']
        posting_sorf = Helper.write_post(user_db,'t_board',session['uname'],title,context)
        if posting_sorf: res['sorf'] = True
        else: res['sorf'] = False
    except:
        res['sorf'] = False
    return res

@app.route('/lecture/write')
def writingPage():
    try:
        if session['uname'] != 'admin': return redirect('/')
        elif session['uname'] == 'admin': return render_template('writelec.html')
    except: return  redirect('/')

@app.route('/auth/<user_token>')
def authPage(user_token):
    try:
        email = Helper.token_base.loads(user_token, salt=Helper.salt,max_age=180)
        checking = Helper.SignUp.check_token(self,user_db,email,user_token)
        if checking: return "CONFIRMED PLEASE CONTINUE SIGN UP PROCESS"
        else: return "An Error Occured."
    except:
        return "Invalid Link or Timed Out Token. Please Check Again."

@app.route('/lecture/<int:postIDX>')
def postPage(postIDX):
    if 'uname' in session:
        return f'postid={postIDX}'
    return redirect('/signin')

@app.route('/test/geturl')
def testPage():
    t1 = request.args.get('t1')
    if t1 == None : return 'retry'
    return t1

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=1)

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)