from threading import Thread

def Async(func):
    def wrapper(*args, **kwargs):
        th = Thread(target=func,args=args,kwargs=kwargs)
        th.start()
    return wrapper