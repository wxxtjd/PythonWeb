var write_lecture = function() {
    $.ajax({
    type: "POST",
    url: "/writelect",
    data:{
    title : $('.title').val(),
    context : $('.context').val()
    },
    success: function(res) {
      if (res.sorf == true) {
          alert('완료');
          location.href = '/'
        }
      else {
        alert('실패');
      }
      }
    });
}
