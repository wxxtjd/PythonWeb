var logout = function() {
    $.ajax({
    type: "POST",
    url: "/logout",
    data:{
    uname : $('.signin-link').val()
    },
    success: function(res){
        if (res.sorf == true) {
            alert('로그아웃 완료');
            location.reload();
        }
        else {
            alert('오류가 발생했습니다.')
            location.reload();
        }
    }
    });
}