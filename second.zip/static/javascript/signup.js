var check_length = function() {
    if ($('.info-signup-email').val() == '') { $('.warning-email').css('display','none'); }
    else if (!($('.info-signup-email').val().includes('@')) || !($('.info-signup-email').val().includes('.'))){ $('.warning-email').css('display','block'); }
    else { $('.warning-email').css('display','none'); }

    if ($('.info-signup-name').val().length < 2 && $('.info-signup-name').val() != ''){ $('.warning-name').css('display','block'); }
    else { $('.warning-name').css('display','none'); }

    if ($('.info-signup-pw').val().length < 6 && $('.info-signup-pw').val() != ''){ $('.warning-pw').css('display','block'); }
    else { $('.warning-pw').css('display','none'); }
}

var check_blank = function() {
  if ($('.info-signup-name').val().length >= 2 && $('.info-signup-email').val().length >= 4 && $('.info-signup-pw').val().length >= 6 && $('.info-signup-pwcheck').val() != '') {
      check_length()

      if ($('.info-signup-pw').val() != $('.info-signup-pwcheck').val()) {
          $('.warning-pwcheck').css("display","block");
          const btn = $('.signup-submit');
          btn.prop('disabled', true);
          btn.css("cursor","Default");
          btn.css("background","#E6E6E6")
          btn.css("color","#818181")
      }
      else {
          const btn = $('.signup-submit');
          $('.warning-pwcheck').css("display","none");
          btn.prop('disabled', false);
          btn.css("cursor","pointer");
          btn.css("background","#43BE48");
          btn.css("color","#FFFFFF");
          }
  }

  else {
      check_length()

      const btn = $('.signup-submit');
      $('.warning-pwcheck').css("display","none");
      btn.prop('disabled', true);
      btn.css("cursor","Default");
      btn.css("background","#E6E6E6")
      btn.css("color","#818181")
  }
}

var checkpw = function() {
    if($('.info-signup-pw').val() != $('.info-signup-pwcheck').val()) {
      return alert('비밀번호가 일치하지 않습니다.');
    }
    else {
    const email = $('.info-signup-email').val();
    const name = $('.info-signup-name').val();
    const pw = $('.info-signup-pw').val();
    $.ajax({
        type: "POST",
        url: "/signup",
        data:{
        usermail:email,
        username:name,
        userpw:pw
        },
        success: function(res){
            if (res.sorf == true) {
                location.replace('/');
                alert(res.message)
            }
            else {
                alert(res.message)
            }
        }
    });
    }
}

$(document).ready(function () {
    $('.info-signup-name').on('input change', function () {
        check_blank();
    });
});
$(document).ready(function () {
    $('.info-signup-pw').on('input change', function () {
        check_blank();
    });
});
$(document).ready(function () {
    $('.info-signup-email').on('input change', function () {
      check_blank();
    });
});
$(document).ready(function () {
    $('.info-signup-pwcheck').on('input change', function () {
        check_blank();
    });
});