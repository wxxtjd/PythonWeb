var submit_inform = function() {
    if ($('.info-signin-ne').val().length < 2 || $('.info-signin-pw').val().length < 6) {
        return alert('이메일 또는 이름, 비밀번호를 다시 확인해주세요.')
    }
    else {
    const ne = $('.info-signin-ne').val();
    const pw = $('.info-signin-pw').val();
    $.ajax({
        type: "POST",
        url: "/signin",
        data:{
        userne:ne,
        userpw:pw
        },
        success: function(res){
            if (res.sorf == true) {
                location.replace('/');
                alert(res.message)
            }
            else {
                location.replace('../signin');
                alert(res.message)
            }
        }
    });
    }
}

var check_blank = function(){
  if ($('.info-signin-ne').val().length >= 2 && $('.info-signin-pw').val().length >= 6) {
      $('.signin-submit').prop('disabled', false);
      $('.signin-submit').css("cursor","pointer");
      $('.signin-submit').css("background","#43BE48")
      $('.signin-submit').css("color","#FFFFFF")
  }
  else {
      $('.signin-submit').prop('disabled', true);
      $('.signin-submit').css("cursor","Default");
      $('.signin-submit').css("background","#E6E6E6")
      $('.signin-submit').css("color","#818181")
  }
}

$(document).ready(function () {
    $('.info-signin-ne').on('input change', function () {
        check_blank();
    });
});
$(document).ready(function () {
    $('.info-signin-pw').on('input change', function () {
        check_blank();
    });
});