from flask_bcrypt import Bcrypt
from flask import Flask, request
import pymysql
import logging
from decorator import Async
import time
from flask_mail import Mail, Message
from datetime import datetime
from itsdangerous import URLSafeTimedSerializer
import re

# logging.basicConfig(filename='C:/Users/황현아/Desktop/File4Log/helper_system_log.txt', level= logging.DEBUG)

hangul = re.compile('[가-힣]+')
filter_name = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890'
filter_email = filter_name + '@.'
filter_pw = filter_name + '!@^*~$'
doa_list = ['A','R','E','UE','SIS','SIF','EF','PF','NF']
doa_type = ['[ADD]','[READ]','[ERROR]','[UNIQUE-ERROR]','[SI-SUCCEED]','[SI-FAILED]','[EMAIL-FILTER]','[PW-FILTER]','[NAME-FILTER]']
doa_str_list = ['New Data is added to Database successfully. ','A Data is read from Database. ', 'An unknown error is occured. ', 'Client tried to make an account with some informaiton already existing. ', 'Sign in succeed. ', 'Sign in failed. ', 'Sign up Failed - Found a not allowed letter filtered in Email. ', 'Sign up Failed - Found a not allowed letter filtered in Password. ','Sign up Failed - Found a not allowed letter filtered in Name. ']

db_password = 'testdbpwd'
db_user_table = 'user_info'
user_db_name = 'members'
SKey = 'douwxxtxdskm'
columns = ['uemail','uname']

token_base = URLSafeTimedSerializer('wxxtxdtoeknsecretkey')
salt = 'wxxtxdemailconfirm'

length_limit = {'email': 4,'name' : 2, 'pw' : 6}
warning_massage = {'email' : '이메일을 다시 확인해주세요.', 'name' : '닉네임은 2글자 이상으로 해주세요.', 'pw' : '비밀번호를 6글자 이상으로 해주세요.'}

def check_form(element,type_):
    if type_ == 'email':
        if '@' not in element or '.' not in element: return warning_massage[type_]
    if length_limit[type_] > len(element): return warning_massage[type_]

# Prevent sql injection through Name
def name_filter(element):
    element = re.sub(hangul,'',element)
    for l in element:
        if l not in filter_name: return '이름은 영어, 숫자, 한글만 사용해주세요.'

# Prevent sql injection through Email
def email_filter(element):
    for l in element:
        if l not in filter_email: return '이메일을 다시 확인해주세요.'

# Prevent sql injection through Password
def pw_filter(element):
    for l in element:
        if l not in filter_pw: return '비밀번호에 특수기호 !, @, ^, *, ~, $ 외 사용 금지'

def sin_ne_filter(element):
    for l in element:
        if l not in filter_email: return '이메일 또는 이름을 다시 확인해주세요.'

# Set app
def setting_app(name,bcrypt_level):
    app = Flask(name)
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 465
    app.config['MAIL_USERNAME'] = 'handj0215@gmail.com'
    app.config['MAIL_PASSWORD'] = 'ovqarnenxhkuygcn'
    app.config['MAIL_USE_TLS'] = False
    app.config['MAIL_USE_SSL'] = True
    app.config['SECRET_KEY'] = SKey
    app.config['BCRYPT_LEVEL'] = bcrypt_level
    return app

# Connect to MySQL
def connect_to_db(host):
    connected_db = pymysql.connect(
        user='root',
        passwd=db_password,
        host=host,
        db=user_db_name,
        charset='utf8'
    )
    return connected_db

#Func for Writing Post(lecture)
def write_post(db,p_table,writer,title,context):
    try:
        with db.cursor() as cur:
            now = datetime.now().strftime('%Y/%m/%d %H:%M')
            views = 0
            cur.execute(f"insert into {p_table} (writer,title,context,views,time) VALUES ('{writer}','{title}','{context}','{views}','{now}')")
            db.commit()
        return True
    except:
        return False

#Get Posts(Main Page)
def get_main_posts(db,p_table):     #***mysql workbench에서 update 시 반영되지 않음 pymysql update시에도 그러는지 확인 필요***
    try:
        post_content = []                                   #***글자 수 맞추기 위한 if () >= 56 고쳐야함. 글자마다 크기가 다름.(백엔드X 프론트엔드 필요)***
        with db.cursor() as cur:
            cur.execute(f'select * from {p_table} order by idx desc limit 3;')
            posts = cur.fetchall()
        for post in posts:
            post_content.append(post[2])
            post_content.append(post[3])
            post_content.append(post[0])
        return {'title1':post_content[0],'title2':post_content[3],'title3':post_content[6],'context1':post_content[1],'context2':post_content[4],'context3':post_content[7],
                'idx1': post_content[2],'idx2': post_content[5],'idx3': post_content[8]}
    except: return False

# Write Log in Log File
def write_log(doa, email, name=None, pw=None, error=None):    #의도치 않은 에러 발생으로 인해 서버 다운시 로그 파일에 작성하는 기능 필요
    now = datetime.now().strftime("[%Y/%m/%d, %H:%M:%S] ")
    client_ip = request.environ['REMOTE_ADDR']
    suffix = doa_type[doa_list.index(doa)] + now + doa_str_list[doa_list.index(doa)]
    details = f"/Email : {email} / Name : {name} , Password : {pw} (DB : {user_db_name} - Table : {db_user_table} / Client_IP : {client_ip})\n"
    if error != None: msg = suffix + f"***{error} / {type(error)}***" + details
    else: msg = suffix + details
    with open('C:/Users/황현아/Desktop/File4Log/user_log.txt', 'a') as lf:
        lf.write(msg)

#Sending E-mail(async)
@Async
def send_email_async(app,token,email):
    mail = Mail(app)
    msg = Message('AUTH MAIL', sender='handj0215@gmail.com', recipients=[email])
    msg.body = f'http://127.0.0.1:5000/auth/{token}'
    with app.app_context():
        mail.send(msg)

# Sign Up Functions
class SignUp:
    def __init__(self):
        pass

    #Sending Link with Token Through Email.
    def sendnadd_token(self,app,db,email):
        token = token_base.dumps(email, salt=salt)
        try:
            with db.cursor() as cur:
                cur.execute(f"select * from user_auth where email = '{email}';")
                existing = cur.fetchone()
                if existing == None: raise Exception("Email Isn't In DB.")
                cur.execute(f"update user_auth set token = '{token}' where email = '{email}';")                  #***sql injection 방지***
                db.commit()
                write_log('A', email)
        except Exception as e:
            with db.cursor() as cur:
                cur.execute(f'INSERT INTO user_auth (email,token,confirmed) VALUES ("{email}","{token}","F")')           #***sql injection 방지***
                db.commit()
                write_log('A',email)
        try:
            send_email_async(app,token,email)
            return True
        except Exception as e:
            print(e,'\n',type(e))
            return 'ERROR:INVALID EMAIL OR DB ERROR'

    #Checking Token
    def check_token(self,db,email,token):
        try:
            with db.cursor() as cur:
                cur.execute(f"select token from user_auth where email='{email}';")
                write_log('R', email)
                db_token = cur.fetchone()[0]
            if token == db_token:
                with db.cursor() as cur:
                    cur.execute(f"update user_auth set confirmed='T' where email='{email}';")
                    db.commit()
                    write_log('A', email)
                    return True
            else: return False
        except Exception as e:
            print(e, '\n', type(e))
            return False

    #Checking User is Confirmed Or Not.
    def check_confirmed(self,db,email):
        try:
            with db.cursor() as cur:
                cur.execute(f"select confirmed from user_auth where email='{email}';")
                confirmed_orn = cur.fetchone()[0]
                if confirmed_orn == 'T': return True
                else: return  False
        except: return False

    #Delete Already Signed Up User's Confirm Data
    def remove_confirm_data(self,db,email):
        try:
            with db.cursor() as cur:
                cur.execute(f"delete from user_auth where email='{email}';")
                db.commit()
            return True
        except: return False

    def create_account(self, db, email, name, password, flask_app):
        checking_list = [check_form(email,'email'), check_form(name,'name'), check_form(password,'pw')]
        for elem in checking_list:
            if elem: return elem
        filtering_list = {name_filter(name) : 'NF' ,email_filter(email) : 'EF',pw_filter(password) : 'PF'}
        for elem in filtering_list:
            if elem:
                write_log(filtering_list[elem], email, name, password)
                return elem
        bcrypt = Bcrypt(flask_app)
        hash_pw = bcrypt.generate_password_hash(password)
        hash_pw = str(hash_pw)
        hash_pw = hash_pw[2:-1]
        try:
            with db.cursor() as cur:
                cur.execute(f"INSERT INTO {db_user_table} (uemail, uname, upw) VALUES ('{email}','{name}','{hash_pw}');")
                db.commit()
                write_log('A',email,name)
                return True #DB에 데이터 추가 성공 시 True 반환
        except Exception as e:
            if type(e) == pymysql.err.IntegrityError:
                write_log('UE',email,name)
                return '이메일 또는 이름이 이미 존재합니다.'
            write_log('E',email,name,password,e)
            return f'An error occured. {e}' #DB에 데이터 추가 실패 시 Flase 반환

# Sign In Functions
class SignIn:
    def __init__(self):
        pass

    def check_account(self, db, ne, password, flask_app):
        filtering_list = [sin_ne_filter(ne), pw_filter(password)]
        for filter in filtering_list:
            if filter: return filter
        bcrypt = Bcrypt(flask_app)
        for column in columns:
            try:
                with db.cursor() as cur:
                    cur.execute(f"SELECT upw FROM {db_user_table} WHERE {column}='{ne}';")
                    write_log('R', ne)
                    result = cur.fetchone()
                    hashed_pw = bytes(result[0],'utf-8')
                    if bcrypt.check_password_hash(hashed_pw, password):
                        write_log('SIS', ne)
                        return True
                    else:
                        write_log('SIF', ne)
                        return "이메일 또는 닉네임, 비밀번호를 다시 확인해주세요."
            except Exception as e:
                write_log('SIF',ne,None,None,e)
                pass
        return "이메일 또는 닉네임, 비밀번호를 다시 확인해주세요."

    def create_session(self, db, ne):
        if '@' in ne or '.' in ne:
            with db.cursor() as cur:
                cur.execute(f"SELECT uname FROM {db_user_table} WHERE uemail='{ne}';")
                write_log('R', ne)
                result = cur.fetchone()
                return result[0]
        else:
            return ne